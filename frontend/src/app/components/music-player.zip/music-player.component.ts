import { Component, OnInit } from '@angular/core';
import { Howl } from 'howler';

@Component({
  selector: 'app-music-player',
  templateUrl: './music-player.component.html',
  styleUrls: ['./music-player.component.css']
})
export class MusicPlayerComponent {
    id1 : number;
    playFlag : boolean = false;
    autoFlag : boolean = false;
    muteFlag : boolean = false;
    loopFlag : boolean = false;

    constructor() {
        var sound = new Howl({
            src : ['./Kalimba.mp3'],
            html5 : true,
        })

        this.id1 = sound.play();

        sound.onload(this.id1, () => {
            sound.play()
            this.playFlag = true;
        })
        sound.onloaderror(this.id1, () => {
            console.log('음악을 불러오는데 실패했습니다.');
        })  
    }
    /*
    playMusic() {
        this.playFlag = true;
        this.sound.play();
    }

    pauseMusic() {
        this.playFlag = false;
        this.sound.pause();
    }

    muteMusic() {
        if(this.muteFlag) {
            this.sound.mute(true, this.id1);
        } else {
            this.sound.mute(false, this.id1);
        }
    }
    
    loopMusic() {
        if(this.loopFlag) {
            this.sound.loop(true, this.id1);
        } else {
            this.sound.loop(false, this.id1);
        }
    }
    */
}
